"use strict";
use(function() {
    var resourceResolver = resource.getResourceResolver();
    return {
      items : resourceResolver.getResource(currentNode.getPath() + "/images"),
    };
});